import java.sql.*;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.Connection;
public class TransactionMgt {
	public static void main(String arg[]) throws Exception {
		Class.forName("oracle.jdbc.driver.OracleDriver");
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "SYSTEM", "123");
        
        System.out.println("Connected");
        Statement stmt = con.createStatement();
        
        //Disable AutoCommit;
        con.setAutoCommit(false);
        
        try {
        	stmt.executeUpdate("insert into employee values(202,'Shay', 40000)");
        	stmt.executeUpdate("update employee set ENAME = 'Rani' where EID  = 201");
        	stmt.executeUpdate("delete from employee where EID = 101");
        	con.commit();
        	System.out.println("Transaction is success");
        }
        catch(Exception e) {
        	try {
        		con.rollback();
        		System.out.println("Transaction is failed");
        	}catch(Exception e1) {
        		System.out.println(e1);
        	}
        }
        stmt.close();
        con.close();
	}
}

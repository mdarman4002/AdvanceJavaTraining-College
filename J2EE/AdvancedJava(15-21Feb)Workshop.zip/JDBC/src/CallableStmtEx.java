import java.util.*;
import java.sql.*;
public class CallableStmtEx {
	Connection con;
	public void openConnection() throws Exception{
		Class.forName("oracle.jdbc.driver.OracleDriver");
        con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "SYSTEM", "123");
        
        System.out.println("Connected");
	}
	public void callProcedure() throws Exception{
		CallableStatement cstmt = con.prepareCall("{call emp_exp_pro(?,?,?)}");
		Scanner s = new Scanner(System.in);
		System.out.println("Enter employee id: ");
		int eid = s.nextInt();
		cstmt.setInt(1, eid);
		
		// register output;
		cstmt.registerOutParameter(2,Types.VARCHAR);
		cstmt.registerOutParameter(3,Types.INTEGER);
		cstmt.execute();
		
		String str = cstmt.getString(2);
		int exp = cstmt.getInt(3);
		
		System.out.println("Name "+str);
		System.out.println("Experience in yrs "+ exp);
	}
	public void closeConnection() throws Exception{
		con.close();
	}
	public static void main(String args[]) throws Exception{
		CallableStmtEx co = new CallableStmtEx();
		co.openConnection();
		co.callProcedure();
		co.closeConnection();
	}
}

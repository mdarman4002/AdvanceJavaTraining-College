import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class FirstProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Class.forName("jdbc.odbc.driver.OracelDriver");
			Connection con=DriverManager.getConnection("obdc:jdbc:thin:@localhost:2001:xe","system","Mohsin8467");
			Statement stmt=con.createStatement();
			stmt.executeUpdate("create table game(gmid number,gmname varchar(12)");
			System.out.println("connected sucessfully");
			stmt.close();
			con.close();
			System.out.println("closed");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}

	}

}
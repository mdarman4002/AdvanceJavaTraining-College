package arman.bean;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TravelService {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(Config.class);
		Vehicle vo = context.getBean("car",Vehicle.class);
		System.out.println(vo.move());
	}

}

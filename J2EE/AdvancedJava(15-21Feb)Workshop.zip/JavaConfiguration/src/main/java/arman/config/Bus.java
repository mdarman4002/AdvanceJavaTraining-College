package arman.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Bus implements Vehicle {
	@Autowired
	@Qualifier("noDiscount")
	private Discount discount;
	
	@Value("${car.mrp}")
	private int price;
	@Override
	public String move() {
		// TODO Auto-generated method stub
		return "Travvel by Bus";
	}
	public String callDiscount() {
		return discount.showMessage();
	}
	@Override
	public int getPrice() {
		// TODO Auto-generated method stub
		return price;
	}

}

package arman.config;

import org.springframework.stereotype.Component;

@Component
public class FestivalDiscount implements Discount {

	@Override
	public String showMessage() {
		// TODO Auto-generated method stub
		return "20% discount on Festival";
	}

}

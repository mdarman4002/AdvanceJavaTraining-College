package arman;

public class SalaryBean {
	private int sal;

	public int getSal() {
		return sal;
	}

	public  void setSal(int sal) {
		this.sal = sal;
	}
	public double calculateNetSal() {
		double da = sal*0.10;
		double hra = sal*.2;
		double netsal = sal + da + hra;
		return netsal;
	}
}

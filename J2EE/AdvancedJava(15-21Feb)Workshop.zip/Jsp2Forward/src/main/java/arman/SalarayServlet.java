package arman;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
public class SalarayServlet extends HttpServlet {
	public void doGet(HttpServletRequest req,HttpServletResponse res)throws IOException{
		String str1 = req.getParameter("t1");
		String str2 = req.getParameter("p1");
		
		int s = Integer.parseInt(str1);
		double d = Double.parseDouble(str2);
		
		//find HRA
		double h = s*0.32;
		PrintWriter pw = res.getWriter();
		pw.println("<h1>");
		pw.println("Salary: "+s);
		pw.println("<br>");
		pw.println("DA: "+d);
		pw.println("<br>");
		pw.println("HRA: "+h);
		pw.println("</h1");
		pw.close();
	}
}

package com.annotation.vehicle;


import org.springframework.stereotype.Component;

@Component("festival")
public class FestivalDiscount implements Discount {

	@Override
	public String showDiscount() {
		// TODO Auto-generated method stub
		return "75% discount on Festival";
	}

}

package com.arman;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.arman")
public class Config {
	public Process Apple() {
		Apple apple = new Apple();
		return apple;
	}
}

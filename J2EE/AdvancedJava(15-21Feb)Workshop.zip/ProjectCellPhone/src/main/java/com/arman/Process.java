package com.arman;

public interface Process {
	String processor();

}

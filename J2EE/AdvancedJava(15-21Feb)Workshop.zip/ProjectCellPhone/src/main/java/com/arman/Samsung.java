package com.arman;

public class Samsung implements Process{
	public String processor() {
		return "Samsung processor";
	}
}

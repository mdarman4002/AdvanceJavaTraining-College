/**
 * 
 */
package com.arman;

/**
 * 
 */
public class FestivalDiscount implements Discount{
	public String showDiscount() {
		return "20% discount";
	}
}

package com.arman;

public interface Discount {
	String showDiscount();
}

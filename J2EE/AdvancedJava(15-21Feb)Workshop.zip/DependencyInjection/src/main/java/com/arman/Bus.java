package com.arman;

public class Bus implements Vehicle {
	private Discount discount;
	private int price;
	private String brandName;
//	public Discount getDiscount() { // setter injection
//		return discount;
//	}
//	public void setDiscount(Discount discount) {
//		this.discount = discount;
//	}
	
	
public Discount getDiscount() {
		return discount;
	}
	public void setDiscount(Discount discount) {
		this.discount = discount;
	}
	public String getBrandName() {
		return brandName;
	}
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	//	public Bus(Discount discount) {  // constructor injeciton
//		this.discount = discount;
//	}
	public String  move() {
		return "Move by Bus";
	}
	public String callDiscount() {
		return discount.showDiscount();
	}
}

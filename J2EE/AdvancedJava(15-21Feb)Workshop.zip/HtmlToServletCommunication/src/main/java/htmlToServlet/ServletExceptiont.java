package htmlToServlet;

public class ServletExceptiont extends Exception {

}

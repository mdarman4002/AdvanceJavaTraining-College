package arman;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SaveEmployee extends HttpServlet{
	public void doGet(HttpServletRequest req,HttpServletResponse res)throws IOException, ServletException{
	
		
		try {
	        Class.forName("oracle.jdbc.driver.OracleDriver");
	        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "SYSTEM", "123");
	        System.out.println("connected successfully");
	        
	        PreparedStatement pstmt = con.prepareStatement("insert into employee values(?,?,?)");
	        
	        int eid = Integer.parseInt(req.getParameter("id"));
	        String name = req.getParameter("name");
	        
	        int salary = Integer.parseInt(req.getParameter("salary"));
	        
	        pstmt.setInt(1, eid);
	        pstmt.setString(2, name);
	        pstmt.setInt(3, salary);
	        
	        int i = pstmt.executeUpdate();
	        PrintWriter pw = res.getWriter();
	        pw.println("<h1> ");
	        pw.println("Row inserted");
	        pw.println("</h1>");
//	        stmt.close();
//	        con.close();
//	        System.out.println("closed");
	    } catch (Exception e) {
	        System.out.println(e);
	    }
	}
	

}

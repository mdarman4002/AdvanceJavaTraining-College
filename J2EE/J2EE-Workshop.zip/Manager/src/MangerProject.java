
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class MangerProject {

	public static void main(String[] args) {
		try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:Oracle:thin:@localhost:1521:xe", "system", "123");
            System.out.println("CONNECTED");
            Statement stmt = con.createStatement();
            stmt.executeUpdate("create table Manager(M_id number,M_name varchar(20),M_salary number(10), M_dept varchar(20))");
            stmt.executeUpdate("insert into Manager values(101,'Arman',1700000,'Sales')");
            stmt.executeUpdate("insert into Manager values(102,'Ujjawal',850000,'software Developer')");
            stmt.executeUpdate("insert into Manager values(103,'Adarsh',850000,'Tester')");
            stmt.executeUpdate("insert into Manager values(104,'Durgesh Singh',900000,'Team Manager')");
            stmt.executeUpdate("insert into Manager values(105,'Mahatma',800000,'Project Manager')");
            System.out.println("5 row inserted");
            stmt.close();
            con.close();
            System.out.println("closed");
        } catch (Exception var3) {
            var3.printStackTrace();
       }
	}
}

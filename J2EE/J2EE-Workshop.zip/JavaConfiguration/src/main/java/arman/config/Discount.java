package arman.config;

public interface Discount {
	String showMessage();
}

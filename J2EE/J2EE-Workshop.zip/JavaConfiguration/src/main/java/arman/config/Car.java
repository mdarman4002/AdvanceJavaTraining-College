package arman.config;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component

public class Car implements Vehicle {
	@Autowired
	@Qualifier("noDiscount")
	private Discount discount;
	private int price;
	@Override
	public String move() {
		// TODO Auto-generated method stub
		return "Travel by car";
	}
	public String callDiscount() {
		return discount.showMessage();
	}
	@Override
	public int getPrice() {
		// TODO Auto-generated method stub
		return price;
	}

}

package arman.config;

public interface Vehicle {
	String move();
	String callDiscount();
	int getPrice();
}

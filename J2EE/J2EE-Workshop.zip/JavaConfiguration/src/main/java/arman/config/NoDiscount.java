package arman.config;

import org.springframework.stereotype.Component;

@Component
public class NoDiscount implements Discount {

	@Override
	public String showMessage() {
		// TODO Auto-generated method stub
		return "NO DISCOUNT";
	}

}

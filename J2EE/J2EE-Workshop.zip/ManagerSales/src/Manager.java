import java.sql.*;

public class Manager {
    public static void main(String[] args) {
        ResultSet resultSet = null;
        Statement statement = null;
        Connection connection = null;

        try {
            // Load the Oracle JDBC driver
            Class.forName("oracle.jdbc.driver.OracleDriver");

            // Establishing a connection to the database
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "123");
            System.out.println("CONNECTED");

            // Creating a statement object
            statement = connection.createStatement();

            // SQL query to retrieve manager details whose department is Sales
            String sqlQuery = "SELECT * FROM employees WHERE department = 'Sales' AND title = 'Manager'";

            // Executing the query
            resultSet = statement.executeQuery(sqlQuery);

            // Displaying the results
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                String department = resultSet.getString("department");
                String title = resultSet.getString("title");
                System.out.println("ID: " + id + ", Name: " + name + ", Department: " + department + ", Title: " + title);
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Closing the resources in the reverse order of their creation
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}

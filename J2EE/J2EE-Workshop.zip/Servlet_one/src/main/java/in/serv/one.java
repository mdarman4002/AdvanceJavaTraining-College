package in.serv;

public class one implements Servlet {
	
}

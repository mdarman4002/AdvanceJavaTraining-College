package com.annotation.vehicle;

public interface Discount {
	String showDiscount();
}

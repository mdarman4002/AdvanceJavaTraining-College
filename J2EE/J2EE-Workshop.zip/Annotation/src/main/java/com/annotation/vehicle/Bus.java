
//------------------------------------------------------------------------
package com.annotation.vehicle;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("myBus") // Passing id is optional as by default it takes class name as id
public class Bus implements Vehicle {
	
//	@Autowired
	private Discount discount;
	@Value("${car.mrp}")
	private int price;
/*	public Bus(Discount discount) {
		this.discount=discount;
	} */
	public String move() {
		// TODO Auto-generated method stub
		return "travel by bus";
	}
	public String callDiscount() {
		return discount.showDiscount();
	}
	
	// SETTER AND GETTER METHOD !!!!
	@Autowired
	@Qualifier("no")
	public void setDiscount(Discount discount) {
		this.discount = discount;
	}
	
	public Discount getDiscount() {
		return discount;
	}
	public int getPrice() {
		// TODO Auto-generated method stub
		return price;
	}
	

	
	
}
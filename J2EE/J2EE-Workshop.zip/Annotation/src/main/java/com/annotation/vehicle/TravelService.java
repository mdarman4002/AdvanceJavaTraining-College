package com.annotation.vehicle;


// -------------------------------------------



import org.springframework.context.support.ClassPathXmlApplicationContext;



public class TravelService {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("config.xml");
		Vehicle vo = context.getBean("myCar",Vehicle.class);
		Vehicle vo1 = context.getBean("myCar",Vehicle.class);
		System.out.println(vo.move());
		
		System.out.println(vo.getPrice());
		
		System.out.println(vo.callDiscount());
		
		
		// checking if the object is same or not
		
		if(vo == vo1) {
			System.out.println("Same Object");
		}else {
			System.out.println("Different Object");
		}

	}

}

package com.annotation.vehicle;

public interface Vehicle {
	String move();
	String callDiscount();
	int getPrice();
}

package com.annotation.vehicle;


// ----------------------------------------

	
	
	


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("myCar") // Passing id is optional as by default it takes class name as id
@Scope("prototype")
public class Car implements Vehicle {
	
//	@Autowired
	private Discount discount;
	@Value("${car.mrp}")
	private int price;
	
	// CONSTRUCTOR
	
/*	public Car(Discount discount) {
		this.discount=discount;
	}*/
	@Override
	
	public String move() {
		// TODO Auto-generated method stub
		return "travel by car";
	}
	
	@Override
	public int getPrice() {
		// TODO Auto-generated method stub
		return price;
	}
	
	public String callDiscount() {
		return discount.showDiscount();
	}

	@Autowired
	@Qualifier("no")
	public void setDiscount(Discount discount) {
		this.discount = discount;
	}
	
	public Discount getDiscount() {
		return discount;
	}


}

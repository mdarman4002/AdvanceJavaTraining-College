package com.arman;

public class Car implements Vehicle{
	private Discount discount;
	private int price;
	public String getBrandName() {
		return brandName;
	}
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	private String brandName;
	
	public Discount getDiscount() {
		return discount;
	}
	public void setDiscount(Discount discount) {
		this.discount = discount;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}

	
//	public Discount getDiscount() {  setter injection
//		return discount;
//	}
//	public void setDiscount(Discount discount) {
//		this.discount = discount;
////	}
//	public Car(Discount discount) {  // constructor injeciton
//		this.discount = discount;
//	}
	public String  move() {
		return "Move by Car";
	}
	
	public String callDiscount() {
		return discount.showDiscount();
	}
}

package com.arman;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TravelService {

	public static void main(String[] args) {
//		Car car = new C ar();
//		Bus bus = new Bus();
//		System.out.println(car.move());
//		System.out.println(bus.move());
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("config.xml");
		Vehicle vo = context.getBean("myVehicle",Vehicle.class);
		Vehicle voBus = context.getBean("myBusVehicle", Vehicle.class);
		System.out.println(vo.move());
		System.out.println(vo.callDiscount());
		//System.out.println(voBus.move());
		System.out.println(vo.getBrandName());
		System.out.println(vo.getPrice());
		
	}   

}

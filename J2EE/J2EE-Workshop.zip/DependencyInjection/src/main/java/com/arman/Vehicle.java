package com.arman;

public interface Vehicle {
	String move();
	String callDiscount();
	String getBrandName();
	int getPrice();
}

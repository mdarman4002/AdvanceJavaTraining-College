import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class JDBC_Connect {

    public static void main(String[] args) {
        
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "SYSTEM", "123");

            Statement stmt = con.createStatement();
            stmt.executeUpdate("create table Manager(M_Id number, M_Name varchar(12), M_Salary number,M_Dept varchar(15 )");
            //M_Id,M_Name,M_Salary,M_Dept
            //stmt.executeUpdate("create table employee(eid number, ename varchar(20), salary number(10)");

            System.out.println("connected successfully");
            stmt.close();
            con.close();
            System.out.println("closed");
        } catch (Exception e) {
            System.out.println(e);
        }

    }
}

package arman;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Main {
    public static void main(String[] args) {
        // Define your Person entity
        Person person = new Person();
        person.setName("John");
        person.setAge(30);

        // Insert the person into the database
        insertPerson(person);
    }

    public static void insertPerson(Person person) {
        try {
            // Load Oracle JDBC driver
            Class.forName("oracle.jdbc.driver.OracleDriver");

            // Establish connection
            Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "SYSTEM", "123");
            System.out.println("Connected successfully");

            // Prepare SQL statement
            String query = "INSERT INTO person (name, age) VALUES (?, ?)";
            PreparedStatement statement = conn.prepareStatement(query);

            // Set parameters
            statement.setString(1, person.getName());
            statement.setInt(2, person.getAge());

            // Execute SQL statement
            statement.executeUpdate();

            // Close resources
            statement.close();
            conn.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
}

class Person {
    private String name;
    private int age;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}

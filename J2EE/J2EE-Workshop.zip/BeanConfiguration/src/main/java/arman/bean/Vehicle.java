package arman.bean;

public interface Vehicle {
	String move();
}

package arman.bean;

public class Car implements Vehicle{
	public String move() {
		return "car moved";
	}
}

package com.arman;


import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String loginId = request.getParameter("loginId");
        String password = request.getParameter("password");

        // Authenticate the user using the loginId and password
        // This is just a dummy implementation for the example
        if ("admin".equals(loginId) && "password".equals(password)) {
            // Authentication successful

            // Create a new session
            HttpSession session = request.getSession();

            // Store user's information in the session
            User user = new User();
            user.setFullName("John Doe");
            user.setAddress("123 Main St.");
            session.setAttribute("user", user);

            // Forward to the home page
            RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
            dispatcher.forward(request, response);

        } else {
            // Authentication failed
            request.setAttribute("error", "Invalid loginId or password");
            RequestDispatcher dispatcher = request.getRequestDispatcher("index.html");
            dispatcher.forward(request, response);
        }
    }
}


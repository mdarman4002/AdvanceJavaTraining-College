package com.arman;

import java.io.ObjectInputFilter.Config;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Mediatek {
	
	public static void main(String[] args) {
			// TODO Auto-generated method stub
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(Config.class);
		Process vo = context.getBean("apple",Process.class);
		System.out.println(vo.processor());
	}
	
}

package com.arman;

public class Apple implements Process {
	public String processor() {
		return "Apple processor";
	}
}

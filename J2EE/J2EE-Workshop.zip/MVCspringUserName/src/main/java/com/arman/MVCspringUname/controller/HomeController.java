package com.arman.MVCspringUname.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController {
	
	@RequestMapping(value="/login", method = RequestMethod.POST)
	public String myForm(@RequestParam("uname") String name1,@RequestParam("pwd")String pa, Model model) {
		model.addAttribute("un", name1);
		if(name1.equals("Arman") && (pa.equals("1234"))) {
			return "success";
		}
		return "fail";
		
	} 
	@RequestMapping("/MVCspringUserName/login/home")
	public String home() {
		return "home";
	}

	@RequestMapping(value="/")
	public ModelAndView test(HttpServletResponse response) throws IOException{
		return new ModelAndView("home");
	}
	
}

package arman;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SelectById extends HttpServlet {
	public void doGet(HttpServletRequest req , HttpServletResponse res) throws IOException , ServletException{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","123");
			System.out.println("Connected");
			int a = Integer.parseInt(req.getParameter("id"));
			String query = "select * from employee where EID = ?";
			PreparedStatement smt = con.prepareStatement(query);
			smt.setInt(1, a);
	
			ResultSet rs = smt.executeQuery();
			rs.next();
			// System.out.println(a);
			PrintWriter pw = res.getWriter();
			pw.println("<body bgcolor=cyan><center><table border = 2>");
			pw.println("<tr>");
			pw.println("<td>");
			pw.println(rs.getInt(1));				
			pw.println("</td>");
			pw.println("<td>");
			pw.println(rs.getString(2));				
			pw.println("</td>");
			
			pw.println("<td>");
			pw.println(rs.getInt(3));				
			pw.println("</td>");
			
			pw.println("</tr>");
			pw.println("</table></center></body>");
			}catch(Exception e) {
				System.out.println(e);
			}
	
	}
}

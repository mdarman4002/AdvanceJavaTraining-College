package arman;

import java.sql.Statement;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ShowEmpoyee extends HttpServlet{
	public void doGet(HttpServletRequest req , HttpServletResponse res) throws IOException , ServletException{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
			System.out.println("Connected");
			Statement smt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			ResultSet rs = smt.executeQuery("select * from employee");
			PrintWriter pw = res.getWriter();
			pw.println("<h1>Employees</h1>");
			rs.afterLast();
			while(rs.previous()) {
				pw.println("<table>");
				pw.println("<tr>");
				
				pw.println("<td>");
				pw.println(rs.getInt(1));				
				pw.println("</td>");
				
				pw.println("<td>");
				pw.println(rs.getString(2));				
				pw.println("</td>");
				
				pw.println("<td>");
				pw.println(rs.getInt(3));				
				pw.println("</td>");
				
				pw.println("</tr>");
				pw.println("</table>");
			}
			
			}catch(Exception e) {
				System.out.println(e);
			}
	}
}

package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Servlet2 extends HttpServlet{
	public void doGet(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException{
		String v1 = req.getParameter("p1");
		PrintWriter pw = res.getWriter();
		pw.println("<h1> From Servlet2 </h1>"+v1);
		pw.close();
	}
}
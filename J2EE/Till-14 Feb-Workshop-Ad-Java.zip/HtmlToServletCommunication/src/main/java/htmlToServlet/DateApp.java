package htmlToServlet;


import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
public class DateApp extends HttpServlet{
	
	
	public void doGet(HttpServletRequest req,HttpServletResponse res)throws IOException{
		PrintWriter pw = res.getWriter();
		res.setHeader("Refresh","1");
		java.util.Date d = new java.util.Date();
		pw.println("<h1>"+d.toString()+"</h1>");
		pw.close();
	}

}

package htmlToServlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.*;

public class HtmlToServletCommunicationClass extends GenericServlet {

	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		System.out.println("Servlet called");
		String s1 = req.getParameter("un");
		String s2 = req.getParameter("pwd");
		PrintWriter pw = res.getWriter();
		
		if(s1.equals("ARMAN") && s2.equals("123")) {
			pw.println("<h1> Successful </h1>");
		}
		else {
			pw.println("<h1> Invalid </h1>");
		}
	}

}

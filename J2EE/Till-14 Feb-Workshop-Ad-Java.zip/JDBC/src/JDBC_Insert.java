import java.sql.*;
import java.util.*;
import java.sql.Connection;
import java.sql.DriverManager;

public class JDBC_Insert {

	public static void main(String[] args) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "SYSTEM", "123");
            
            System.out.println("Connected");
            
            PreparedStatement pstmt = con.prepareStatement("insert into employee values(?,?,?)");
            
            Scanner s = new Scanner(System.in);
            String choice = "yes";
            
            while (choice.equals("yes")) {
            	System.out.println("Enter emp id:");
            	int eid = s.nextInt();
            	
            	System.out.println("Enter emp name: ");
            	String ename = s.next();
            	
            	System.out.println("Enter emp salary: ");
            	int salary = s.nextInt();
            	
            	pstmt.setInt(1,  eid);
            	pstmt.setString(2, ename);
            	pstmt.setInt(3,  salary);
            	
            	int i = pstmt.executeUpdate();
            	
            	System.out.println(i +"row inserted");
            	System.out.println("Do you want to insert another data then (yes/) ");
            	
            	choice = s.next();
            	
            }
            pstmt.close();
            con.close();

		}catch(Exception e) {
			System.out.println(e);
		}


	}

}
